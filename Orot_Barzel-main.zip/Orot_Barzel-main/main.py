def main():
    print("Hello from orot-barzel!")


if __name__ == "__main__":
    main()
